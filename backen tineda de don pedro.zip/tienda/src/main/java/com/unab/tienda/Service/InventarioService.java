package com.unab.tienda.Service;

import com.unab.tienda.Collection.Inventarios;
import com.unab.tienda.IRepository.IInventariosRepository;
import com.unab.tienda.IService.IInventariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InventarioService implements IInventariosService {

    @Autowired
    IInventariosRepository repository;

    @Override
    public List<Inventarios> all() {
        return repository.findAll();
    }

    @Override
    public Optional<Inventarios> findById(String id) {
        return repository.findById(id);
    }

    @Override
    public Inventarios save(Inventarios inventarios) {
        return repository.save(inventarios);
    }

    @Override
    public void delete(String id) {
        repository.deleteById(id);

    }
}
