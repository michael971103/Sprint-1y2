package com.unab.tienda.IService;

import com.unab.tienda.Collection.Inventarios;

import java.util.List;
import java.util.Optional;

public interface IInventariosService {

    public List<Inventarios> all();

    public Optional<Inventarios> findById(String id);

    public Inventarios save(Inventarios inventarios);

    public void delete(String id);
}
