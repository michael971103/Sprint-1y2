package com.unab.tienda.IRepository;

import com.unab.tienda.Collection.Inventarios;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface IInventariosRepository extends MongoRepository<Inventarios, String> {
}
